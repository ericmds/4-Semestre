/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package javaapplication2;

/**
 *
 * @author laboratorio
 */
public class PesquisaDigital extends javax.swing.JFrame {

    /**
     * Creates new form PesquisaDigital
     */
    public PesquisaDigital() {
        initComponents();
    }

    StringBuffer historico = new StringBuffer();

    private int contarPalavras(StringBuffer texto) {
        return texto.toString().split(" ").length;
    }
    
    // Outra forma de contar palavras (recomendado)
    private int contarPalavras2(StringBuffer texto) {
        String ts = texto.toString().replace('\n', ' ');
        String vetor[] = ts.split(" ");
        int total = vetor.length;
        
        return total;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txt_Area = new javax.swing.JTextArea();
        lbl_Titulo = new javax.swing.JLabel();
        lbl_TotalCaracteres = new javax.swing.JLabel();
        lbl_TotalPalavras = new javax.swing.JLabel();
        lbl_Pesquisa = new javax.swing.JLabel();
        lbl_Frase = new javax.swing.JLabel();
        txt_Frase = new javax.swing.JTextField();
        txt_Pesquisa = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txt_Caracteres = new javax.swing.JTextField();
        txt_TotalCaracteres = new javax.swing.JTextField();
        txt_TotalPalavras = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txt_Area.setEditable(false);
        txt_Area.setColumns(20);
        txt_Area.setRows(5);
        jScrollPane1.setViewportView(txt_Area);

        lbl_Titulo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbl_Titulo.setText("Pesquisa Digital");

        lbl_TotalCaracteres.setText("Total de caracteres:");

        lbl_TotalPalavras.setText("Total de palavras:");

        lbl_Pesquisa.setText("Pesquisa:");

        lbl_Frase.setText("Frase:");

        txt_Frase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_FraseActionPerformed(evt);
            }
        });
        txt_Frase.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_FraseKeyReleased(evt);
            }
        });

        jLabel1.setText("Caracteres:");

        txt_Caracteres.setEditable(false);

        txt_TotalCaracteres.setEditable(false);

        txt_TotalPalavras.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lbl_Pesquisa)
                                    .addComponent(lbl_Frase)
                                    .addComponent(jLabel1))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_Frase)
                                    .addComponent(txt_Pesquisa)
                                    .addComponent(txt_Caracteres)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(129, 129, 129)
                        .addComponent(lbl_Titulo)
                        .addGap(0, 130, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lbl_TotalPalavras)
                            .addComponent(lbl_TotalCaracteres))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_TotalCaracteres)
                            .addComponent(txt_TotalPalavras))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_Titulo)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_Frase)
                    .addComponent(txt_Frase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_Pesquisa)
                    .addComponent(txt_Pesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_Caracteres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_TotalCaracteres)
                    .addComponent(txt_TotalCaracteres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_TotalPalavras)
                    .addComponent(txt_TotalPalavras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_FraseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_FraseActionPerformed

    }//GEN-LAST:event_txt_FraseActionPerformed

    private void txt_FraseKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_FraseKeyReleased
        StringBuffer frase;
        frase = new StringBuffer(txt_Frase.getText());
        if (evt.getKeyCode() == 10) {
            historico.append(frase.toString().toUpperCase()).append("\n");
            txt_Frase.setText(historico.toString());
            txt_Frase.setText("");
        } else {
            txt_Area.setText(historico.toString() + frase.toString().toUpperCase());
        }
        
        txt_TotalCaracteres.setText("" + txt_Area.getText().length());
        txt_TotalPalavras.setText("" + contarPalavras2(new StringBuffer(txt_Area.getText())));
    }//GEN-LAST:event_txt_FraseKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PesquisaDigital.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PesquisaDigital.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PesquisaDigital.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PesquisaDigital.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PesquisaDigital().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_Frase;
    private javax.swing.JLabel lbl_Pesquisa;
    private javax.swing.JLabel lbl_Titulo;
    private javax.swing.JLabel lbl_TotalCaracteres;
    private javax.swing.JLabel lbl_TotalPalavras;
    private javax.swing.JTextArea txt_Area;
    private javax.swing.JTextField txt_Caracteres;
    private javax.swing.JTextField txt_Frase;
    private javax.swing.JTextField txt_Pesquisa;
    private javax.swing.JTextField txt_TotalCaracteres;
    private javax.swing.JTextField txt_TotalPalavras;
    // End of variables declaration//GEN-END:variables
}
