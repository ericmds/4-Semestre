import time
import os

from Util import Util
from Ordenacao import Ordenacao

lista_bolha = []
lista_normal = []
lista_selecao = []
lista_insercao = []
lista_agitacao = []
lista_pente = []
lista_quicksort = []

tamanho = 30000

Util.popular_lista_aleatoria(lista_bolha, tamanho, 1000, 20000)
lista_quicksort.extend(lista_bolha)

# Quicksort
qtd_comparacoes = 0
qtd_trocas = 0
tempo_inicio = time.perf_counter()
Ordenacao.quicksort(lista_quicksort, 0, len(lista_quicksort) - 1)
tempo_fim = time.perf_counter()
print("Tempo da rotina ordenar por quick: ", (tempo_fim - tempo_inicio) , "s")      
print('Comparacoes:', Ordenacao.qtd_comparacoes)
print('Trocas:', Ordenacao.qtd_trocas)