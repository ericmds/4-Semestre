class Ordenacao:
    qtd_comparacoes = 0
    qtd_trocas = 0

    @staticmethod
    def particiona(lista, ini, fim):

        pivo = lista[ini]
        i = ini +1
        j = fim

        while i <= j:
            while i <= fim and lista[i] <= pivo:
                Ordenacao.qtd_comparacoes += 1
                i += 1

            while j > ini and lista[j] > pivo:
                Ordenacao.qtd_comparacoes += 1
                j -= 1

            if i < j:
                Ordenacao.qtd_comparacoes += 1
                lista[i], lista[j] = lista[j], lista [i]
        
        Ordenacao.qtd_trocas += 1
        lista[ini], lista[j] = lista[j], lista[ini]

        return j
    
    @staticmethod
    def quicksort(lista, ini, fim):
        if ini < fim:
            pivo = Ordenacao.particiona(lista, ini, fim)
            Ordenacao.quicksort(lista, ini, pivo - 1)
            Ordenacao.quicksort(lista, pivo + 1, fim)