#include <stdio.h>

int qtdComparacoes = 0;
int qtdTrocas = 0;

int particiona(int *vetor, int ini, int fim) {
    int pivo = ini;
    int tmp;

    while (fim > ini) {
        // da direita para esquerda
        while (fim > pivo && vetor[fim] > vetor[pivo]) {
            fim--;
            qtdComparacoes++;
        }

        if (fim > pivo) {
            qtdTrocas++;
            tmp = vetor[pivo];
            vetor[pivo] = vetor[fim];
            vetor[fim] = tmp;
            pivo = fim;
        }

        // da esquerda para direita
        while (ini < pivo && vetor[ini] < vetor[pivo]) {
            ini++;
            qtdComparacoes++;
        }

        if (ini < pivo) {
            qtdTrocas++;
            tmp = vetor[pivo];
            vetor[pivo] = vetor[ini];
            vetor[ini] = tmp;
            pivo = ini;
        }
    }

    return pivo;
}

void quickSort(int *vetor, int ini, int fim) {
    if (ini < fim) {
        int pivo = particiona(vetor, ini, fim);
        if (ini < pivo - 1)
            quickSort(vetor, ini, pivo - 1);
        if (pivo + 1 < fim)
            quickSort(vetor, pivo + 1, fim);
    }
}

void imprimeVetor(int *vetor, int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

int main() {
    int vetor[] = {9, 3, 7, 1, 4, 8, 6, 2, 5};
    int tamanho = sizeof(vetor) / sizeof(vetor[0]);

    printf("Vetor original:\n");
    imprimeVetor(vetor, tamanho);

    quickSort(vetor, 0, tamanho - 1);

    printf("\nVetor ordenado:\n");
    imprimeVetor(vetor, tamanho);

    printf("\nNúmero de comparações: %d\n", qtdComparacoes);
    printf("Número de trocas: %d\n", qtdTrocas);

    return 0;
}