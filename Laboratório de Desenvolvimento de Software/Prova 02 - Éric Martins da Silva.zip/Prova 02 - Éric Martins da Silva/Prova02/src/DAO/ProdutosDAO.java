package DAO;

import Beans.Produtos;
//import com.mysql.cj.jdbc.PreparedStatementWrapper;
import Conexao.Conexao;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Éric PC
 */
public class ProdutosDAO {

    private Conexao conexao;
    private Connection conn;

    /**
     * Contrutor para realizar a conexão com o banco Atividade
     */
    public ProdutosDAO() {

        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    /**
     * Insere um novo registro de produto no banco
     *
     * @param p Objeto contendo nome, preco e saldo
     */
    public void cadastrar(Produtos p) {
        try {
            String sql = "INSERT INTO produtos(nome, preco, saldo) VALUES (?, ?, ?);";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setFloat(2, p.getPreco());
            stmt.setInt(3, p.getSaldo());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao CADASTRAR o PRODUTO: " + ex.getMessage());
        }
    }

    /**
     * Retorna uma lista com todos os produtos do banco
     *
     * @return a lista de objetos ou null se dar algum erro
     */
    public List<Produtos> getProdutos() {
        try {
            String sql = "SELECT * FROM produtos;";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            List<Produtos> listaProdutos = new ArrayList<>();
            while (rs.next()) {
                Produtos p = new Produtos();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getFloat("preco"));
                p.setSaldo(rs.getInt("saldo"));
                listaProdutos.add(p);
            }
            return listaProdutos;

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! Erro ao BUSCAR todos os PRODUTOS: " + ex.getMessage());
            return null;
        }
    }

    /**
     * Busca um produto do banco pelo seu Id
     *
     * @param id do produto
     * @return objeto correspondente ao id informado ou null se nao encontrar
     * nada
     */
    public Produtos getProdutos(int id) {
        try {
            String sql = "SELECT * FROM produtos WHERE id = ?;";

            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Produtos p = new Produtos();
            rs.first();

            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getFloat("preco"));
            p.setSaldo(rs.getInt("saldo"));
            return p;

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao BUSCAR o PROFESSORES pelo Id" + ex.getMessage());
            return null;
        }
    }
}
