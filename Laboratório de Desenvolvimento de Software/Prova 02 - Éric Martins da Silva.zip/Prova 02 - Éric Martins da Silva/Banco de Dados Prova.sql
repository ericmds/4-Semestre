CREATE DATABASE prova;
USE prova;

CREATE TABLE produtos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  preco FLOAT CHECK (preco > 0),
  saldo int CHECK (saldo > 0)
);