package DAO;

import Beans.Professores;
import com.mysql.cj.jdbc.PreparedStatementWrapper;
import Conexao.Conexao;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Éric PC
 */
public class ProfessoresDAO {

    private Conexao conexao;
    private Connection conn;

    /**
     * Contrutor para realizar a conexão com o banco Atividade
     */
    public ProfessoresDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    /**
     * Insere um novo registro de professor no banco
     *
     * @param p Objeto contendo nome e email do professor
     */
    public void cadastrar(Professores p) {
        try {
            String sql = "INSERT INTO professores(nome, email) VALUES (?, ?);";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getEmail());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! Erro ao cadastrar PROFESSOR: " + ex.getMessage());
        }
    }

    /**
     * Atualiza as informações de um professor existente no banco pelo seu Id
     *
     * @param p Objeto contendo Id, nome e email atualizados
     */
    public void editar(Professores p) {
        try {
            String sql = "UPDATE professores SET nome = ?, email = ? WHERE id = ?;";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getEmail());
            stmt.setInt(3, p.getId());

            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! Erro ao atualizar PROFESSORES: " + ex.getMessage());
        }
    }

    /**
     * Exclui um professor do banco, com base no Id
     *
     * @param id do professor que vai ser removido
     */
    public void excluir(int id) {
        try {
            String sql = "DELETE FROM professores WHERE id = ?;";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);

            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! Erro ao excluir PROFESSORES: " + ex.getMessage());
        }
    }

    /**
     * Retorna uma lista com todos os professores do banco
     *
     * @return a lista de objetos ou null se dar algum erro
     */
    public List<Professores> getProfessores() {
        try {
            String sql = "SELECT * FROM professores;";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            List<Professores> listaProfessores = new ArrayList<>();
            while (rs.next()) {
                Professores p = new Professores();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setEmail(rs.getString("email"));
                listaProfessores.add(p);
            }
            return listaProfessores;

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! Erro ao buscar todos os PROFESSORES: " + ex.getMessage());
            return null;
        }
    }

    /**
     * Busco um professor do banco pelo seu Id
     *
     * @param id do professor
     * @return objeto correspondente ao id informado ou null se nao encontrar nada
     */
    public Professores getProfessores(int id) {
        try {
            String sql = "SELECT * FROM professores WHERE id = ?;";

            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Professores p = new Professores();
            rs.first();

            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setEmail(rs.getString("email"));
            return p;

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao BUSCAR o PROFESSORES pelo Id" + ex.getMessage());
            return null;
        }
    }

    /**
     * Filtra professores pelo nome
     *
     * @param nome do professor
     * @return lista de objetos que corresponde ao nome
     */
    public List<Professores> getProfessores(String nome) {
        try {
            String sql = "SELECT * FROM professores WHERE nome LIKE ?;";

            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();

            List<Professores> listaProfessores = new ArrayList<>();
            while (rs.next()) {
                Professores p = new Professores();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setEmail(rs.getString("email"));
                listaProfessores.add(p);
            }
            return listaProfessores;
        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! Erro ao consultar PROFESSORES: " + ex.getMessage());
            return null;
        }
    }
}
