package DAO;

import Beans.Professores;
import Beans.Disciplinas;
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Éric PC
 */
public class DisciplinasDAO {

    private Conexao conexao;
    private Connection conn;

    /**
     * Contrutor para realizar a conexão com o banco Atividade
     */
    public DisciplinasDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    /**
     * Insere uma disciplina no banco
     *
     * @param d Objeto contendo nome, carga horária e professor associado ao
     * banco
     */
    public void cadastrar(Disciplinas d) {
        try {
            String sql = "INSERT INTO disciplinas(nome, carga_horaria, professor_id) VALUES (?, ?, ?);";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, d.getNome());
            stmt.setInt(2, d.getCarga_horaria());
            stmt.setInt(3, d.getProfessor_id().getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao CADASTRAR a DISCIPLINA: " + ex.getMessage());
        }
    }

    /**
     * Atualiza uma disciplina existente no banco
     *
     * @param d Objeto com os novos dados
     */
    public void editar(Disciplinas d) {
        try {
            String sql = "UPDATE disciplinas SET nome = ?, carga_horaria = ?, professor_id = ? WHERE id = ?;";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, d.getNome());
            stmt.setInt(2, d.getCarga_horaria());
            stmt.setInt(3, d.getProfessor_id().getId());
            stmt.setInt(4, d.getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao EDITAR a DISCIPLINA");
        }
    }

    /**
     * Exclui um disciplina do banco com base no seu Id
     *
     * @param id da disciplina
     */
    public void excluir(int id) {
        try {
            String sql = "DELETE FROM disciplinas WHERE id = ?;";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);

            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao EXCLUIR a DISCIPLINA: " + ex.getMessage());
        }
    }

    /**
     * Retorna todas as disciplinas cadastradas
     *
     * @return lista disciplinas ou null
     */
    public List<Disciplinas> getDisciplinas() {
        try {
            String sql = "SELECT * FROM disciplinas;";

            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            List<Disciplinas> listaDisciplinas = new ArrayList<>();
            while (rs.next()) {
                Disciplinas d = new Disciplinas();
                d.setId(rs.getInt("id"));
                d.setNome(rs.getString("nome"));
                d.setCarga_horaria(rs.getInt("carga_horaria"));
                ProfessoresDAO pDAO = new ProfessoresDAO();
                Professores p = pDAO.getProfessores(rs.getInt("professor_id"));
                d.setProfessor_id(p);

                listaDisciplinas.add(d);
            }
            return listaDisciplinas;

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao BUSCAR todas as DISCIPLINAS: " + ex.getMessage());
            return null;
        }
    }

    /**
     * Busca uma disciplina pelo Id
     *
     * @param id da disciplina
     * @return objeto correspondente ao Id ou null
     */
    public Disciplinas getDisciplinas(int id) {
        try {
            String sql = "SELECT * FROM disciplinas WHERE id = ?;";

            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Disciplinas d = new Disciplinas();
            rs.first();

            d.setId(rs.getInt("id"));
            d.setNome(rs.getString("nome"));
            d.setCarga_horaria(rs.getInt("carga_horaria"));
            ProfessoresDAO pDAO = new ProfessoresDAO();
            Professores p = pDAO.getProfessores(rs.getInt("professor_id"));
            d.setProfessor_id(p);

            return d;

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao BUSCAR a DISCIPLINA pelo Id" + ex.getMessage());
            return null;
        }
    }

    /**
     * Busca disciplinas pelo nome da disciplina
     *
     * @param nome da disciplina
     * @return lista de objetos que correspondente
     */
    public List<Disciplinas> getDisciplinas(String nome) {
        try {
            String sql = "SELECT * FROM disciplinas WHERE nome LIKE ?;";

            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();

            List<Disciplinas> listaDisciplinas = new ArrayList<>();
            while (rs.next()) {
                Disciplinas d = new Disciplinas();
                d.setId(rs.getInt("id"));
                d.setNome(rs.getString("nome"));
                d.setCarga_horaria(rs.getInt("carga_horaria"));
                ProfessoresDAO pDAO = new ProfessoresDAO();
                Professores p = pDAO.getProfessores(rs.getInt("professor_id"));
                d.setProfessor_id(p);
                listaDisciplinas.add(d);
            }
            return listaDisciplinas;

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! Erro ao consultar DISCIPLINAS pelo NOME: " + ex.getMessage());
            return null;
        }
    }

    /**
     * Retorna todas as disciplinas de um professor
     *
     * @param idProfessor do professor
     * @return lista de disciplinhas associadas ao professor
     */
    public List<Disciplinas> getDisciplinasProfessor(int idProfessor) {
        try {
            String sql = "SELECT * FROM disciplinas WHERE professor_id = ?;";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idProfessor);
            ResultSet rs = stmt.executeQuery();

            List<Disciplinas> listaDisciplinas = new ArrayList<>();
            while (rs.next()) {
                Disciplinas d = new Disciplinas();
                d.setId(rs.getInt("id"));
                d.setNome(rs.getString("nome"));
                d.setCarga_horaria(rs.getInt("carga_horaria"));
                ProfessoresDAO pDAO = new ProfessoresDAO();
                Professores p = pDAO.getProfessores(rs.getInt("professor_id"));
                d.setProfessor_id(p);

                listaDisciplinas.add(d);
            }
            return listaDisciplinas;

        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao BUSCAR a DISCIPLINA por PROFESSOR: " + ex.getMessage());
            return null;
        }
    }

    /**
     * Retorna o professor responsavel por uma disciplina
     *
     * @param idDisciplina da disciplina
     * @return objeto de professor com nome e email
     */
    public Professores getProfessoresDisciplina(int idDisciplina) {
        Professores professor = null;

        try {
            String sql = "SELECT p.nome, p.email FROM professores AS p INNER JOIN disciplinas AS d ON d.professor_id = p.id WHERE d.id = ?;";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idDisciplina);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                professor = new Professores();
                professor.setNome(rs.getString("nome"));
                professor.setEmail(rs.getString("email"));
            }

            return professor;
        } catch (SQLException ex) {
            System.out.println("ATENÇÃO! ERRO ao BUSCAR os PROFESSORES pela DISCIPLINA");
            return null;
        }
    }
}
