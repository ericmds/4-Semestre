-- Cria��o do Banco de Dados
CREATE DATABASE atividade;
USE atividade;

-- Cria��o das tabelas
CREATE TABLE professores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(60) NOT NULL,
  email VARCHAR(60) UNIQUE
);

CREATE TABLE disciplinas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL,
  carga_horaria INT NOT NULL,
  professor_id INT NOT NULL,
  FOREIGN KEY (professor_id) REFERENCES professores(id)
);

-- Visualizar as tabelas
SHOW TABLES;

-- Inser��o de dados em professores
INSERT INTO professores (id, nome, email) VALUES 
  (1, 'Eric', 'eric@email.com'),
  (2, 'Anna Luiza', 'annaluiza@email.com'),
  (3, 'Claiton', 'claiton@email.com'),
  (4, 'Ang�lica', 'angelica@email.com'),
  (5, 'La�s', 'lais@email.com'),
  (6, 'Lucas', 'lucas@email.com'),
  (7, 'Gael', 'gael@email.com');

-- Inser��o de dados em disciplinas
INSERT INTO disciplinas (id, nome, carga_horaria, professor_id) VALUES
  (1, 'Laboratorio de Desenvolvimento', 60, 1),
  (2, 'Anatomia', 80, 2),
  (3, 'Laboratorio de Desenvolvimento', 60, 3),
  (4, 'C�lculo', 90, 3),
  (5, 'Anatomia', 80, 5),
  (6, 'C�lculo', 90, 6),
  (7, 'Ingl�s', 40, 7);

-- Descri��o das tabelas
DESC professores;
DESC disciplinas;