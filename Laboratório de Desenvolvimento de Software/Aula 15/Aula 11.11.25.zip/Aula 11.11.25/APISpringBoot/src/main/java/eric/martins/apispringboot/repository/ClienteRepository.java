package eric.martins.apispringboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eric.martins.apispringboot.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    @Repository
    public interface Cliente extends JpaRepository<Cliente, Long> {

    }
}
