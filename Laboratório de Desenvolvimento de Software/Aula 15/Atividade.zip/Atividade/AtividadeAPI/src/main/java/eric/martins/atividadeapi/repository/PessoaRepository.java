package eric.martins.atividadeapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eric.martins.atividadeapi.model.Pessoa;

@Repository
public interface PessoaRepository extends JpaRepository<Pessoa, Long> {
    boolean existsByIdioma(Long idioma);

    Pessoa findByIdioma(Long idioma);
}