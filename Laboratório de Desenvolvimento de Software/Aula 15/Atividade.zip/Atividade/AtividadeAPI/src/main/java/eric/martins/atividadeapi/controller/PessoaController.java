package eric.martins.atividadeapi.controller;
import eric.martins.atividadeapi.repository.PessoaRepository;
import eric.martins.atividadeapi.model.Pessoa;

import org.apache.coyote.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pessoas")
public class PessoaController {

    private final PessoaRepository pessoaRepository;

    public PessoaController(PessoaRepository pessoaRepository) {
        super();
        this.pessoaRepository = pessoaRepository;
    }

    @GetMapping
    public List<Pessoa> listar() {
        return pessoaRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Pessoa adicionar(@RequestBody Pessoa pessoa) {
        return pessoaRepository.save(pessoa);
    }

    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<Void> deletarPessoa(@PathVariable Long id) {

        if(!pessoaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        pessoaRepository.deleteById(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pessoa> atualizarPessoa(@PathVariable Long id, @RequestBody Pessoa pessoaAtualizada) {

        if(!pessoaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        Pessoa pessoaExistente = pessoaRepository.findById(id).orElse(null);

        if(pessoaExistente != null) {
            pessoaExistente.setNome(pessoaAtualizada.getNome());
            pessoaExistente.setSexo(pessoaAtualizada.getSexo());
            pessoaExistente.setIdioma(pessoaAtualizada.getIdioma());
            Pessoa pessoaAtualizadaNoBanco = pessoaRepository.save(pessoaExistente);

            return ResponseEntity.ok(pessoaAtualizadaNoBanco);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{id}/{idioma}")
    public ResponseEntity<Pessoa>  buscarPessoaIdioma(@PathVariable Long idioma) {
        if (!pessoaRepository.existsByIdioma(idioma)) {
            return ResponseEntity.notFound().build();
        }

        Pessoa pessoa = pessoaRepository.findByIdioma(idioma);

        if (pessoa != null) {
            return ResponseEntity.ok(pessoa);
        }else{
            return ResponseEntity.notFound().build();
        }
    }
}
