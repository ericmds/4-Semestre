package eric.martins.atividadeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
