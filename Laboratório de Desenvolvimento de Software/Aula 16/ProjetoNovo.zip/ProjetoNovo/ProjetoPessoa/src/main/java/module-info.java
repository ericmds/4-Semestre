module eric.martins.projetopessoa {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens eric.martins.projetopessoa to javafx.fxml;

    exports eric.martins.projetopessoa;

    opens eric.martins.projetopessoa.controller to javafx.fxml;
}