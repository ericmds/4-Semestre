/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Beans.Veiculo;
import com.mysql.cj.jdbc.PreparedStatementWrapper;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;

/**
 *
 * @author laboratorio
 */
public class VeiculoDAO {

    private Conexao conexao;
    private Connection conn;

    public VeiculoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    public void inserir(Veiculo veiculo) {
        String sql = "INSERT INTO veiculos (marca, modelo, ano, placa, cor) VALUES (?, ?, ?, ?, ?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, veiculo.getMarca());
            stmt.setString(2, veiculo.getModelo());
            stmt.setInt(3, veiculo.getAno());
            stmt.setString(4, veiculo.getPlaca());
            stmt.setString(5, veiculo.getCor());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir veiculo: " + ex.getMessage());
        }
    }

    public Veiculo getVeiculo(int id) {
        String sql = "SELECT * FROM veiculos WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            Veiculo v = new Veiculo();
            rs.first();
            v.setId(id);
            v.setMarca(rs.getString("marca"));
            v.setModelo(rs.getString("modelo"));
            v.setAno(rs.getInt("ano"));
            v.setPlaca(rs.getString("placa"));
            v.setCor(rs.getString("cor"));
            return v;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar veiculo: " + ex.getMessage());
            return null;
        }
    }
}